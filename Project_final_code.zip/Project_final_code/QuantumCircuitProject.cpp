// PHYS 30762 Programming in C++
// Assignment 5

// A matrix class - skeleton code
// Student no.: 10621489

// You are advised to write your own code from scratch but
// you may use this code if you do not know how to get started.

// Note: for longer functions, you are advised to prototype them
// within class and put the function code itself immediately below class. 

#include<iostream>
#include<cstdlib> // for c style exit
#include<vector>
#include<sstream>
#include<algorithm>
#include<iomanip>
#include<cmath>
#include<stdexcept>
#include<complex>
#include<memory>
#include<map>
#include<type_traits>
#include<cctype>
#include<regex>
#include<unordered_set>
#include<chrono>
#include<thread>

//matrix.h
class matrix
{
  // Friends
  friend std::ostream & operator<<(std::ostream &os, const matrix &mat);
  friend std::istream & operator>>(std::istream &is, matrix &mat);
private:
  std::complex<double> *matrix_data {nullptr};
  int rows{0};
  size_t size;
  int columns{0};
public:
  // Default constructor, constructs an empty 2x2 matrix by default.
  matrix(){
    this->rows = 2;
    this->columns = 2;
    this->size = 4;
    this->matrix_data = new std::complex<double> [4]{0}; // All entries set to zero
  }
  // Parameterized constructor
  matrix(int rows, int columns){
    this->rows = rows;
    this->columns = columns;
    this->size = rows*columns;
    this->matrix_data = new std::complex<double>[size];
  }
  // Destructor
  ~matrix(){
    delete[] matrix_data;
    matrix_data = nullptr;
  }
  // Access functions
  int get_rows() const {return rows;} // Return number of rows
  int get_cols() const {return columns;} // Return number of columns
  int index(int m, int n) const // Return position in array of element (m,n)
  {
    if(m>0 && m<=rows && n>0 && n<=columns) return (n-1)+(m-1)*columns;
    else {std::cout<<"Error: out of range"<<std::endl; exit(1);}
  }
  std::complex<double> & operator()(int m, int n)const{return matrix_data[index(m,n)];}

  //Set data:
  void set_data(std::vector<std::complex<double>> &vector);
  // Copy constructor
  matrix(const matrix &mat);
  // Move constructor
  matrix(matrix &&mat);
  // Copy  Assignment operator
  matrix & operator=(const matrix &mat);
  // Move Assignment operator
  matrix & operator=(matrix&& mat);
  // Multiplication and tensor product
  matrix operator*(matrix& mat);
  matrix tensor_product(matrix& mat_B);
};
//matrix.cpp
void matrix::set_data(std::vector<std::complex<double>> &vector)
{
  if (vector.size() == size){
    for(size_t i{0}; i<size; i++){ 
			matrix_data[i] = vector[i];
			}
    } 
  else{
		std::cout<<std::endl;
    std::cout<<"Error: The array must have the same number of elements as the matrix"<<std::endl; 
    exit(1);
  }
}
//Copy Constructor
matrix::matrix(const matrix &mat)
{
  // Copy size and declare new array
  matrix_data = nullptr; 
  rows = mat.rows;
  columns = mat.columns;
  size = mat.size;
  if(size > 0) {
    matrix_data = new std::complex<double>[size];
    // Copy values into new array
    for(size_t i{0}; i < size; i++){
      matrix_data[i] = mat.matrix_data[i];
    }
  }
}
//Move Constructor
matrix::matrix(matrix &&mat)
{ 
  size = mat.size;
  rows = mat.rows;
  columns = mat.columns;
  matrix_data = mat.matrix_data;
  mat.columns = 0;
  mat.rows = 0;
  mat.size = 0;
  mat.matrix_data = nullptr;
}
//Copy assignment
matrix & matrix::operator=(const matrix &mat)
{
    std::cout<<"COPY assin"<<std::endl;

  if(&mat == this){ 
    std::cout<<"Self-assignment in copy assignment operator"<<std::endl;  
    return *this; // no self assignment
  }
    // First delete this object's array
  delete[] matrix_data; matrix_data = nullptr; size = 0;
    // Now copy size and declare new array
  size = mat.size;
  rows = mat.rows;
  columns = mat.columns;
  if(size > 0){
    matrix_data = new std::complex<double>[size];
    // Copy values into new array
    for(size_t i{}; i < size; i++) matrix_data[i] = mat.matrix_data[i];
  }
  return *this; // Special pointer!!!
}
//Move Assignment
matrix & matrix::operator=(matrix&& mat)
{   
  std::swap(rows, mat.rows);
  std::swap(columns, mat.columns);
  std::swap(size, mat.size);
  std::swap(matrix_data, mat.matrix_data);
  mat.columns = 0;
  mat.rows = 0;
  mat.size = 0;
  mat.matrix_data = nullptr;
  return *this; 
}

//Matrix operations:
//Multiplication
matrix matrix::operator*(matrix& mat)
{
  matrix temp(rows, mat.columns);
  if (columns == mat.rows){
		for(int i{1}; i <= rows; i++){
			for(int j{1}; j <= mat.columns; j++){
				std::complex<double> sum = 0;
				for(int k{1}; k <= columns; k++){
					sum += operator()(i, k) * mat(k, j);
				}
				temp(i, j) = sum;
			}
		}
	} 
	else{
		std::cout<<std::endl;
    std::cout<<"Error: These two matrices are not compatible for multiplication"<<std::endl; 
    temp.matrix_data[0] = {NAN};
  }
  return temp;
}
//Kronecker Product
matrix matrix::tensor_product(matrix& mat_B) 
{
  int rows_A = this->rows;
  int cols_A = this->columns;
  int rows_B = mat_B.rows;
  int cols_B = mat_B.columns;
  matrix temp(rows_A * rows_B, cols_A * cols_B);
  for (int i{1}; i <= rows_A; ++i) {
    for (int j{1}; j <= cols_A; ++j) {
      for (int k{1}; k <= rows_B; ++k) {
        for (int l{1}; l <= cols_B; ++l) {
          temp((i-1) * rows_B + k, (j-1) * cols_B + l) = operator()(i,j) * mat_B(k,l);
        }
      }
    }
  }
  return temp;
}

//Namespace utilized for custom implementation of operator<< function for complex numbers
namespace complex_custom
{
  // Function to overload << operator for complex numbers
  std::ostream & operator<<(std::ostream &output, const std::complex<double> number);
}
std::ostream & complex_custom::operator<<(std::ostream &output, const std::complex<double> number)
{	
	if(number.imag() < 0){
		output<<number.real()<<number.imag()<<"i";
	}
	else if(number.imag() == 0){
		output<<number.real();
	}
	else{
		output<<number.real()<<"+"<<number.imag()<<"i";
	}
	return output;
}

// Overload insertion to output stream for matrices

std::ostream & operator<<(std::ostream &output, const matrix &mat)
{
  using complex_custom::operator<<;
  int max_width = 0;
  std::stringstream ss;
  if(mat.size > 0){
    for(int i{1}; i <= mat.rows; i++){
      for(int j{1}; j <= mat.columns; j++){
        ss.str("");
        if(mat(i,j).imag() == 0){
          ss<<std::setw(4)<<mat(i,j).real();
        }
        else{
          ss<<std::setw(4)<<mat(i,j);
        }
        max_width = std::max(max_width, static_cast<int>(ss.str().length())); 
      }
    }
    for(int i{1}; i <= mat.rows; i++){
      output << "[  ";
      for(int j{1}; j <= mat.columns; j++){
      	ss.str("");
        if(mat(i,j).imag() == 0){
        	ss<<std::setw(3)<<mat(i,j).real();
        }
        else{
          ss<<std::setw(3)<<mat(i,j);
        }
        output<<ss.str()<<std::string(max_width - ss.str().length(), ' ');
      }
      output << "  ]" << std::endl;
    }
  }
  else{
		std::cout<<std::endl;
    output << "Error: This matrix has no elements.";
  }
  output << std::endl;
  return output;
}

// Overload the extraction operator for the matrix class
std::istream & operator>>(std::istream &input, matrix &mat) 
{
  std::vector<std::complex<double>> values;
  char delimiter;
  std::complex<double> value; 
  std::cout<<"Please enter values for your matrix, "<<mat.size<<" values expected:";
    // Read values separated by commas
  while (input>>value) {
    values.push_back(value);
    if (input.eof() || input.peek() == '\n') {
    	break;
    }
    input>>delimiter;
    if (delimiter != ',' || input.peek() == ',' || input.peek() == '\n') {
      throw std::invalid_argument("Please enter values as such X,X,X,X");
    }
  }
  // Check if the correct number of elements were input
  if (values.size() != mat.size) {
    std::cerr<<"Incorrect number of elements. Expected "<<mat.size<<" elements."<<std::endl;
    std::cerr<<"Please enter the elements again: ";
    input.clear();
    input.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return input>>mat;
  }
  // Assign values to the matrix
  mat.set_data(values);
  return input;
}

//To go in 'quantum_gate.h'
class quantum_comp
{
  protected:
		int qbit_range;
		matrix qoperator;
		virtual void set_operator() = 0;
  public:
    quantum_comp(int rows, int columns, int qbit_range ) : qbit_range{qbit_range}, qoperator(rows, columns){}
    virtual ~quantum_comp() = default;
    virtual std::string get_symbol() = 0;
		virtual std::string get_name() = 0;
		virtual void get_info() = 0;
		int get_qbit_range(){return qbit_range;}
    matrix get_matrix(){return qoperator;}
};

class pauli_X : public quantum_comp 
{	
	private:
		void set_operator();
  public:
    ~pauli_X(){}
    pauli_X(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class pauli_Y : public quantum_comp 
{
	private:
		void set_operator();
  public:
    ~pauli_Y(){}
		pauli_Y(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class pauli_Z : public quantum_comp 
{
	private:
		void set_operator();
  public:
    ~pauli_Z(){}
    pauli_Z(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class hadamard : public quantum_comp 
{
	private:
		void set_operator();
  public:
    ~hadamard(){}
    hadamard(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class phase : public quantum_comp 
{
	private:
		void set_operator();
  public:
    ~phase(){}
    phase(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class identity : public quantum_comp
{
	private:
		void set_operator();
  public:
    ~identity(){}
    identity(): quantum_comp(2,2,1){
      set_operator();
    }
		void get_info();
    std::string get_symbol();
		std::string get_name();
};

class qbit : public quantum_comp
{
  public:
  ~qbit(){}
  void set_operator();
  qbit() : quantum_comp(2,1,1){
    set_operator();
  }
	void get_info();
  std::string get_symbol();
	std::string get_name();
};

class cbit : public quantum_comp
{
	private:
		void set_operator();
  public:
  ~cbit(){}
  cbit() : quantum_comp(1,1,1){
  	set_operator();
  }
	void get_info();
  std::string get_symbol();
	std::string get_name();
};

class cnot : public quantum_comp 
{	
	protected:
		virtual void set_operator();
  public:
    ~cnot(){}
    cnot(): quantum_comp(4,4,2){
    	set_operator();
    }
    cnot(int rows, int columns, int qbit_range) : quantum_comp(rows, columns, qbit_range) {}
		void get_info();
		virtual std::string get_symbol();
    std::string get_name();
};
class target_cnot  : public cnot 
{
	protected:
		virtual void set_operator();
	public:
		virtual ~target_cnot(){}
		target_cnot() : cnot(4,4,1){
			set_operator();
		}
		std::string get_symbol();
};
class target_flip_cnot : public target_cnot
{
	private:
		void set_operator();
	public:
		~target_flip_cnot(){}
		target_flip_cnot() : target_cnot(){
			set_operator();
		}
};
class control_cnot : public cnot 
{
	private:
		void set_operator();
  public:
    ~control_cnot(){}
    control_cnot() : cnot(1,1,1){
      set_operator();
    }
    std::string get_symbol();
};

class cz : public quantum_comp 
{
	protected:
		virtual void set_operator();
  public:
    ~cz(){}
    cz(): quantum_comp(4,4,2){
      set_operator();
    }
    cz(int rows, int columns, int qbit_range) : quantum_comp(rows, columns, qbit_range) {}
		void get_info();
    virtual std::string get_symbol();
		std::string get_name();
};
class target_cz : public cz 
{
	private:
	  void set_operator();
  public:
    virtual ~target_cz(){}
    target_cz() : cz(4,4,1){
      set_operator();
    }
    std::string get_symbol();
};
class control_cz : public cz 
{
	private:
		void set_operator();
  public:
    ~control_cz(){}
    control_cz() : cz(1,1,1){
      set_operator();
    }
    std::string get_symbol();
};

class swap : public quantum_comp 
{
	protected:
		virtual void set_operator();
  public:
    ~swap(){}
    swap(): quantum_comp(4,4,2){
      set_operator();
    }
    swap(int rows, int columns, int qbit_range) : quantum_comp(rows, columns, qbit_range) {}
    virtual std::string get_symbol();
		void get_info();
		std::string get_name();
};
class target_swap : public swap 
{
	private:
	  virtual void set_operator();
  public:
    virtual ~target_swap(){}
    target_swap() : swap(4,4,1){
      set_operator();
    }
    std::string get_symbol();
};
class control_swap : public swap 
{
	private:
	  void set_operator();
  public:
    ~control_swap(){}
    control_swap() : swap(1,1,1){
      set_operator();
    }
    std::string get_symbol();
};

class ccx : public quantum_comp 
{
	protected:
    virtual void set_operator();
  public:
    ~ccx(){}
    ccx(): quantum_comp(8,8,3){
    	set_operator();
    }
    ccx(int rows, int columns, int qbit_range) : quantum_comp(rows, columns, qbit_range) {}
		void get_info();
    virtual std::string get_symbol();
		std::string get_name();
};
class target_ccx  : public ccx 
{
	protected:
		virtual void set_operator();
	public:
		virtual ~target_ccx(){}
		target_ccx() : ccx(8,8,1){
			set_operator();
		}
	std::string get_symbol();
};
class target_flip_ccx : public target_ccx
{
	private:
		void set_operator();
	public:
		~target_flip_ccx(){}
		target_flip_ccx() : target_ccx(){
			set_operator();
		}
};
class control_ccx : public ccx 
{
	private:
    void set_operator();
  public:
    ~control_ccx(){}
    control_ccx() : ccx(1,1,1){
      set_operator();
    }
    std::string get_symbol();
};


//To go in 'quantum_gate.cpp':
void pauli_X::set_operator()
{
  std::vector<std::complex<double>> pauli_x_data = {{0, 0},{1, 0},{1, 0},{0, 0}};
  qoperator.set_data(pauli_x_data); 
}
std::string pauli_X::get_symbol()
{
  return "[X]";
}
void pauli_X::get_info()
{
	std::cout<<"Pauli X Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"Pauli X Gate Symbol: [X]"<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Pauli X: The Pauli gates (X,Y,Z) are the three Pauli matrices and act on a single qubit. The Pauli X, Y and Z equate,"
							"respectively, to a rotation around the x, y and z axes of the Bloch sphere by pi radians. The Pauli-X gate is the quantum"
							" equivalent of the NOT gate for classical computers with respect to the standard basis It is sometimes called a bit-flip "<<std::endl;
}
std::string pauli_X::get_name()
{
	return "Pauli X";
}

void pauli_Y::set_operator()
{
  std::vector<std::complex<double>> pauli_y_data = {{0, 0},{0, -1},{0, 1},{0, 0}};
  qoperator.set_data(pauli_y_data); 
}
std::string pauli_Y::get_symbol()
{
  return "[Y]";
}
void pauli_Y::get_info()
{
	std::cout<<"Pauli Y Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"Pauli Y Gate Symbol: [Y]"<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Pauli Y: The Pauli gates (X,Y,Z) are the three Pauli matrices and act on a single qubit. The Pauli X, Y and Z equate,"
							"respectively, to a rotation around the x, y and z axes of the Bloch sphere by pi radians. The Pauli-X gate is the quantum"
							" equivalent of the NOT gate for classical computers with respect to the standard basis It is sometimes called a bit-flip "<<std::endl;
}
std::string pauli_Y::get_name()
{
	return "Pauli Y";
}

void pauli_Z::set_operator()
{
  std::vector<std::complex<double>> pauli_z_data = {{1, 0},{0, 0},{0, 0},{-1, 0}};
  qoperator.set_data(pauli_z_data);
    
}
std::string pauli_Z::get_symbol()
{
  return "[Z]";
}
void pauli_Z::get_info()
{
	std::cout<<"Pauli Z Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"Pauli Z Gate Symbol: [Z]"<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Pauli X: The Pauli gates (X,Y,Z) are the three Pauli matrices and act on a single qubit. The Pauli X, Y and Z equate,"
							"respectively, to a rotation around the x, y and z axes of the Bloch sphere by pi radians. The Pauli-X gate is the quantum"
							" equivalent of the NOT gate for classical computers with respect to the standard basis It is sometimes called a bit-flip "<<std::endl;
}
std::string pauli_Z::get_name()
{
	return "Pauli Y";
}

void hadamard::set_operator()
{
  std::vector<std::complex<double>> hadamard_data = {{1/sqrt(2), 0},{1/sqrt(2), 0},{1/sqrt(2), 0},{-1/sqrt(2), 0}};
  qoperator.set_data(hadamard_data);
    
}
std::string hadamard::get_symbol()
{
  return "[H]";
}
void hadamard::get_info()
{
	std::cout<<"Hadamard Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"Hadamard Gate Symbol: [H]"<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Hadamard: The Hadamard transform is used extensively in quantum computing. The 2 x 2 Hadamard transform H1 is the quantum logic gate known as the Hadamard gate,"
							" and the application of a Hadamard gate to each qubit of an n-qubit register in parallel is equivalent to the Hadamard transform "
							" H_{n}."<<std::endl;
}
std::string hadamard::get_name()
{
	return "Hadamard";
}

void phase::set_operator()
{
  std::vector<std::complex<double>> phase_data = {{1, 0},{0, 0},{0, 0},{0, 1}};
  qoperator.set_data(phase_data);
    
}
std::string phase::get_symbol()
{
  return "[P]";
}
void phase::get_info()
{
	std::cout<<"Phase Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"Phase Gate Symbol: [P]"<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Phase: info"<<std::endl;
}
std::string phase::get_name()
{
	return "Phase";
}

void qbit::set_operator()
{
  std::vector<std::complex<double>> qbit_data = {{1, 0},{0, 0}};
  qoperator.set_data(qbit_data);
}
std::string qbit::get_symbol()
{
  return "q";
}
void qbit::get_info()
{
	std::cout<<"q-bit Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"q-bit: A quantum bit (qbit) is a basic unit of quantum information—the quantum version of the classic binary" 
						"bit physically realized with a two-state device. A qubit is a two-state (or two-level) quantum-mechanical system,"
						 "one of the simplest quantum systems displaying the peculiarity of quantum mechanics.In a classical system, a bit "
						 "would have to be in one state or the other. However, quantum mechanics allows the qubit to be in a coherent" 
						 "superposition of both states simultaneously, a property that is fundamental to quantum mechanics and quantum computing."<<std::endl;
}
std::string qbit::get_name()
{
	return "Quantum Bit";
}

void cbit::set_operator()
{
  std::vector<std::complex<double>> cbit_data = {{0, 0}};
  qoperator.set_data(cbit_data);
}
std::string cbit::get_symbol()
{
  return"c";
}
void cbit::get_info()
{
	std::cout<<"Classical bit information:"<<std::endl;
	std::cout<<"Cbit info"<<std::endl;
}
std::string cbit::get_name()
{
	return "Classical Bit";
}

void identity::set_operator()
{
  std::vector<std::complex<double>> identity_data = {{1, 0},{0, 0},{0, 0},{1, 0}};
  qoperator.set_data(identity_data); 
}
std::string identity::get_symbol()
{
  return "[I]";
}
std::string identity::get_name()
{
	return "Identity";
}
void identity::get_info()
{
	std::cout<<"Identity Gate Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"Identity: where I is basis independent and does not modify the quantum state." 
							"The identity gate is most useful when describing mathematically the result of"
							 "various gate operations or when discussing multi-qubit circuits."<<std::endl;
}

void cnot::set_operator()
{
  std::vector<std::complex<double>> cnot_data = {{1, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{1, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{1, 0},
                                                {0, 0},{0, 0},{1, 0},{0, 0}};
  qoperator.set_data(cnot_data);
}
std::string cnot::get_symbol()
{
   return "[CX]";
}
std::string cnot::get_name()
{
	return "CNOT";
}
void cnot::get_info()
{
	std::cout<<"CNOT Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"CNOT Gate Symbol: [CX]"<<std::endl;
  std::cout<<"On circuit: "<<std::endl;
  std::cout<<"  ⊕"<<std::endl<<"  |"<<std::endl<<"  •"<<std::endl;
  std::cout<<std::endl;
  std::cout<<"Gate information:"<<std::endl;
	std::cout<<"CNOT: The controlled NOT gate (also CX or CNOT), controlled-X gate is a quantum logic gate that is an essential component in the" 
						" construction of a gate-based quantum computer. It can be used to entangle and disentangle Bell states." 
						"Any quantum circuit can be simulated to an arbitrary degree of accuracy using a combination of CNOT" 
						" gates and single qubit rotations. The gate is sometimes named after Richard Feynman who developed" 
						" an early notation for quantum gate diagrams in 1986."<<std::endl;
}
void control_cnot::set_operator()
{
  std::vector<std::complex<double>> control_data = {{1, 0}};
  qoperator.set_data(control_data); 
}
std::string control_cnot::get_symbol()
{
  return "•";
}
void target_cnot::set_operator()
{
  std::vector<std::complex<double>> target_data = {{1, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{0, 0},{1, 0},
																												{0, 0},{0, 0},{1, 0},{0, 0},
																												{0, 0},{1, 0},{0, 0},{0, 0}};
  qoperator.set_data(target_data);
}
std::string target_cnot::get_symbol()
{
  return "⊕";
}
void target_flip_cnot::set_operator()
{
  std::vector<std::complex<double>> target_flip_data = {{1, 0},{0, 0},{0, 0},{0, 0},
																									{0, 0},{1, 0},{0, 0},{0, 0},
																									{0, 0},{0, 0},{0, 0},{1, 0},
																									{0, 0},{0, 0},{1, 0},{0, 0}};
  qoperator.set_data(target_flip_data);
}

void cz::set_operator()
{
  std::vector<std::complex<double>> cz_data = {{1, 0},{0, 0},{0, 0},{0, 0},
                                              	{0, 0},{1, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{1, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{-1, 0}};
  qoperator.set_data(cz_data);
}
std::string cz::get_symbol()
{
   return "[CZ]";
}
std::string cz::get_name()
{
	return "CZ";
}
void cz::get_info()
{
	std::cout<<"Controlled-Z (CZ) Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"CZ Gate Symbol: [CZ]"<<std::endl;
  std::cout<<"On circuit: "<<std::endl;
  std::cout<<"  ■"<<std::endl<<"  |"<<std::endl<<"  ■"<<std::endl;
  std::cout<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
  std::cout<<std::endl;
	std::cout<<"CZ: In the computational basis, this gate flips the phase of the target qubit if the control qubit is in the state."<<std::endl;
}
void control_cz::set_operator()
{
  std::vector<std::complex<double>> control_data = {{1, 0}};
  qoperator.set_data(control_data); 
}
std::string control_cz::get_symbol()
{
  return "■";
}
void target_cz::set_operator()
{
  std::vector<std::complex<double>> target_data = {{1, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{1, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{1, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{-1, 0}};
  qoperator.set_data(target_data);
}
std::string target_cz::get_symbol()
{
  return "■";
}

void swap::set_operator()
{
  std::vector<std::complex<double>> swap_data = {{1, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{1, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{1, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{-1, 0}};
  qoperator.set_data(swap_data);
}
std::string swap::get_symbol()
{
   return "SWAP";
}
std::string swap::get_name()
{
	return "SWAP";
}
void swap::get_info()
{
	std::cout<<"SWAP Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"SWAP gate on circuit: "<<std::endl;
  std::cout<<"  x"<<std::endl<<"  |"<<std::endl<<"  x"<<std::endl;
  std::cout<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"SWAP: The swap gate swaps the states of the 2 qbits that it is acting on."<<std::endl;
}
void control_swap::set_operator()
{
  std::vector<std::complex<double>> control_data = {{1, 0}};
  qoperator.set_data(control_data); 
}
std::string control_swap::get_symbol()
{
  return "x";
}
void target_swap::set_operator()
{
  std::vector<std::complex<double>> target_data = {{1, 0},{0, 0},{0, 0},{0, 0},
																									{0, 0},{1, 0},{0, 0},{0, 0},
																									{0, 0},{0, 0},{1, 0},{0, 0},
																									{0, 0},{0, 0},{0, 0},{-1, 0}};
  qoperator.set_data(target_data);
}
std::string target_swap::get_symbol()
{
  return "x";
}

void ccx::set_operator()
{
  std::vector<std::complex<double>> ccx_data = {{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},
                                                {0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},
																								{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0}};
                                                
  qoperator.set_data(ccx_data);
}
std::string ccx::get_symbol()
{
   return "[CCX]";
}
std::string ccx::get_name()
{
	return "CCX";
}
void ccx::get_info()
{
	std::cout<<"CCX/Toffoli Matrix Representation:"<<std::endl;
	std::cout<<qoperator;
  std::cout<<"CCX Gate Symbol: [CCX]"<<std::endl;
  std::cout<<"On circuit: "<<std::endl;
  std::cout<<"  ⊕"<<std::endl<<"  |"<<std::endl<<"  •"<<std::endl<<"  |"<<std::endl<<"  •";
  std::cout<<std::endl;
	std::cout<<"Gate information:"<<std::endl;
	std::cout<<"CCX/Toffoli: The Toffoli gate, named after Tommaso Toffoli and also called the CCNOT gate or Deutsch gate " 
 							"is a 3-bit gate which is universal for classical computation but not for quantum computation. The quantum" 
							" Toffoli gate is the same gate, defined for 3 qubits. It is an example of a CC-U (controlled-controlled Unitary)" 
							" gate. Since it is the quantum analog of a classical gate, it is completely specified by its truth table." 
							" The Toffoli gate is universal when combined with the single qubit Hadamard gate."<<std::endl;
}
void control_ccx::set_operator()
{
  std::vector<std::complex<double>> control_data = {{1, 0}};
  qoperator.set_data(control_data); 
}
std::string control_ccx::get_symbol()
{
  return "•";
}
void target_ccx::set_operator()
{
  std::vector<std::complex<double>> target_ccx_data = {{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																															{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																															{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																															{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},
																															{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},
																															{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},
																															{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{1, 0},
																															{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{1, 0},{0, 0}};
  qoperator.set_data(target_ccx_data);
}
std::string target_ccx::get_symbol()
{
  return "⊕";
}
void target_flip_ccx::set_operator()
{
  std::vector<std::complex<double>> target_flip_ccx_data = {{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0},{0, 0},
																												{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},
																												{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{0, 0},{1, 0},{0, 0}};
  qoperator.set_data(target_flip_ccx_data);
}

using circ_element = std::pair<std::vector<int>,std::shared_ptr<quantum_comp>>;
using bit_row = std::vector<circ_element>;
using component_matrix = std::vector<bit_row>;

// Misc. Functions: 
namespace toolbox{
    //Convert to uppercase
    std::string to_upper(std::string& string);
    //Verify integer input
    int int_verifier(const std::string& integer);
    //Extract qbit selection for single and multiple qbits
    int extract_number(const std::string& input);
    std::vector<int> extract_number(const std::string& input, int num_qbits);
    //Longest element in a given vector containing any type
    template<typename T>
    size_t longest_element(const std::vector<std::vector<T>>& vector);
		//Last element in vector that is a gate (not identity)
		size_t last_gate(bit_row components);

    //Circuit matrix tools:
    //Recursive tensor product (for a column of gates in parallel)
    void recursive_tensor_product(const component_matrix& components_vector, int num_qbits, int bit_position, int gate_position, matrix& gate_tensor);
    //Recursive matrix multiplication (for a series of tensor products (gates in series))
    void recursive_matrix_multiplication(std::vector<matrix>& tensor_vector, size_t index, matrix& matrix_product);
}

std::string toolbox::to_upper(std::string& lower)
{
  std::transform(lower.begin(), lower.end(), lower.begin(),
                  [](unsigned char c){return std::toupper(c);
								});
  return lower;
}

int toolbox::int_verifier(const std::string& integer)
{
  for (char c : integer) {
    if (!std::isdigit(c)) {
      return -1;
    }
  }
  return std::stoi(integer);
}

int toolbox::extract_number(const std::string& input)
{
  std::regex pattern("^(q|c)\\d+$");
  std::smatch match;
  int selection;
  if (std::regex_search(input, match, pattern)){
    std::string matched = match.str(0);
    selection = std::stoi(matched.substr(1));
  } 
	else {
    selection = -1;
  }
  return selection;
}

std::vector<int> toolbox::extract_number(const std::string& input, int num_qbits)
{
  std::vector<int> selections;
  selections.reserve(num_qbits);
  std::stringstream ss(input);
  while(ss.good()){
    std::string substring;
    getline(ss, substring, ',' );
    int element_int{toolbox::extract_number(substring)};
    if(element_int == -1){
      selections[0] = -1;
    }
    if(element_int >= num_qbits){
      selections[0] = -2;
    }
    else{
      selections.push_back(element_int);
    }
  }
	if(std::unordered_set<int>{selections.begin(), selections.end()}.size() < selections.size()){
    selections[0] = -1;
	}
  return selections;
}

template<typename T>
size_t toolbox::longest_element(const std::vector<std::vector<T>>& vector) 
{
  size_t maxLength{0};
  for(const auto& innerVec : vector){
    if(innerVec.size() > maxLength){
      maxLength = innerVec.size();
    }
  }
  return maxLength;
}

size_t toolbox::last_gate(bit_row components)
{
	auto it = std::find_if(components.rbegin(),components.rend(), 
													[](const circ_element& ptr){
													return ptr.second->get_symbol() != "[I]";
												});
	size_t position = components.rend() -it;
	return position;
}

void toolbox::recursive_tensor_product(const component_matrix& components_vector, int num_qbits, int bit_position, int gate_position, matrix& gate_tensor)
{
  if(bit_position >= num_qbits){
    return;
  }
  matrix gate_matrix(components_vector[bit_position][gate_position].second->get_matrix());
  gate_tensor = gate_tensor.tensor_product(gate_matrix);
  recursive_tensor_product(components_vector, num_qbits, bit_position+1, gate_position, gate_tensor);
}
void toolbox::recursive_matrix_multiplication(std::vector<matrix>& tensor_vector, size_t index, matrix& matrix_product)
{
  if(index >= tensor_vector.size()){
    return;
  }
  matrix_product = tensor_vector[index]*matrix_product;
  recursive_matrix_multiplication(tensor_vector, index+1, matrix_product);
}

//Library:
namespace Gate_a_base{
	//Library of all possible gates to add:
  typedef std::map<std::string,std::shared_ptr<quantum_comp>> gate_library;
	//Library of designated target and control bits so that the right matrix can be added
	typedef std::map<std::string,std::shared_ptr<quantum_comp>> gate_bit_library;
	//Initializing variables for each
	gate_bit_library bits;
  gate_library gates;
	//Library searcher, takes a key and returns a component
	std::shared_ptr<quantum_comp> search_library(int choice, std::string& request);
	//Function to intialize the library with necessary gates and control bits etc.
  void library_creator();
}

void Gate_a_base::library_creator()
{ 
  using namespace Gate_a_base;
  gates["CNOT"] = std::make_shared<cnot>();
  gates["PAULI X"] = std::make_shared<pauli_X>();
  gates["PAULI Y"] = std::make_shared<pauli_Y>();
  gates["PAULI Z"] = std::make_shared<pauli_Z>();
  gates["HADAMARD"] = std::make_shared<hadamard>();
	gates["PHASE"] = std::make_shared<phase>();
	gates["CZ"] = std::make_shared<cz>();
	gates["SWAP"] = std::make_shared<swap>();
	gates["TOFFOLI"] = std::make_shared<ccx>();

	bits["[CX]_TARGET"] = std::make_shared<target_cnot>();
	bits["[CX]_TARGET_FLIP"] = std::make_shared<target_flip_cnot>();
	bits["[CX]_CONTROL"] = std::make_shared<control_cnot>();
	bits["[CZ]_TARGET"] = std::make_shared<target_cz>();
	bits["[CZ]_CONTROL"] = std::make_shared<control_cz>();
	bits["SWAP_TARGET"] = std::make_shared<target_swap>();
	bits["SWAP_CONTROL"] = std::make_shared<control_swap>();
	bits["[CCX]_TARGET"] = std::make_shared<target_ccx>();
	bits["[CCX]_TARGET_FLIP"] = std::make_shared<target_flip_ccx>();
	bits["[CCX]_CONTROL"] = std::make_shared<control_ccx>();
}

std::shared_ptr<quantum_comp> Gate_a_base::search_library(int choice,std::string& request)
{ 
	auto& library = (choice == 1) ? bits : gates;
  request = toolbox::to_upper(request);
  auto library_iter = library.find(request);
  if(library_iter != library.end()){
		if(library == gates){
			std::cout<<std::endl;
    	std::cout<<" * * Gate retrieved: ("<<request<<")  * *"<<std::endl;
			std::cout<<std::endl;
		}
    return library_iter->second;
  }
  else{
		std::cout<<std::endl; 
    std::cerr<<"Error: Gate '" <<request<<"' is not in database. "<<std::endl;
		std::cout<<"Please enter again: ";
    return nullptr;
  }
}

//q_circuit.h:
class q_circuit
{ 
  private:
  int num_qbits;
	int total_bits;
  component_matrix components_vector;
  matrix circuit_matrix;
  std::vector<matrix> tensor_vector;
	static std::vector<std::shared_ptr<q_circuit>> saved_circuits;
  public:
  q_circuit() : num_qbits{2}{Gate_a_base::library_creator();}
  q_circuit(int q) : num_qbits{q}, total_bits{q+1}{
    components_vector.resize(total_bits);
		for(int i{0}; i < num_qbits; i++){
			components_vector[i].push_back(pair(std::make_shared<qbit>()));
    }
		components_vector[num_qbits].push_back(pair(std::make_shared<cbit>()));
    matrix A(1<<num_qbits,1<<num_qbits);
    circuit_matrix = A;
    Gate_a_base::library_creator();
  }
  ~q_circuit()= default;
  void add_gate();
  void multi_qbit_gate(std::shared_ptr<quantum_comp> gate, int qbit_range, int num_qbits);
  void series_add(std::string gate_choice, std::shared_ptr<quantum_comp> gate);
  void parallel_add(std::shared_ptr<quantum_comp> gate);
	void gate_info();
	void create_circuit();
	void draw_circuit();
  void remove_gate();
  void calculate_circuit_matrix(int gate_pos);
  void get_circuit_matrix();
	void save();
  void load();
  void add_to_circuit(std::shared_ptr<q_circuit> circuit, int circ_no);
	//Pair creator
	circ_element pair(std::vector<int> qbit_choice, std::shared_ptr<quantum_comp> gate);
	circ_element pair(std::shared_ptr<quantum_comp> gate);
};

/*
NOTES:
Please note that this definition should be present in exactly one source file. 
If you put this definition in a header file that's included in multiple source files,
 you'll get multiple definition errors.

 Smart pointers follow RAII (Resource Acquisition Is Initialization) 
 principles and are designed to handle resource deallocation automatically.
*/
//q_circuit.cpp:
std::vector<std::shared_ptr<q_circuit>> q_circuit::saved_circuits;

void q_circuit::multi_qbit_gate(std::shared_ptr<quantum_comp> gate, int qbit_range, int num_qbits)
{
  std::cout<<"Which q-bits would you like this gate to act on?"<<std::endl;
  std::cout<<"Please enter as an array, with the target bit first e.g [q0,q1]: ";
	std::string symbol = gate->get_symbol();
  while(true){
    std::string input;
    std::getline(std::cin, input);
    std::vector<int> bit_array;
    bit_array = toolbox::extract_number(input, num_qbits);
    auto smallest = std::min_element(bit_array.begin(),bit_array.end());
    auto largest = std::max_element(bit_array.begin(),bit_array.end());
    if(bit_array[0] == -2){
			std::cout<<std::endl;
      std::cout<<"Error: There are only "<<num_qbits<<" qbits in the current circuit."<<std::endl;
      std::cout<<"Please enter again: ";
    }
		else if(static_cast<int>(bit_array.size()) != qbit_range){
			std::cout<<std::endl;
			std::cerr<<"Error: Wrong amount of qbits, this gate has a range of "<<qbit_range<<"."<<std::endl;
      std::cerr<<"Please enter again: ";
		}	
    else if((*largest-*smallest +1) > qbit_range ){
      std::cout<<std::endl;
			std::cerr<<"Error: This gate has a range of "<<qbit_range<<" adjacent qubits."<<std::endl;
      std::cerr<<"Please enter again: ";
    }
    else if(bit_array[0] != -1){
      bool replace{true};
      for(const auto& i: bit_array){
        if(components_vector[i].back().second->get_symbol() != "[I]"){
          replace = false;
        }
      }
			std::string ctrl_request = symbol +"_control";
			std::string trgt_request = symbol +"_target";
			std::shared_ptr<quantum_comp> gate_ctrl = Gate_a_base::search_library(1,ctrl_request);
			std::shared_ptr<quantum_comp> gate_trgt = Gate_a_base::search_library(1,trgt_request);
			int max_element = *(std::max_element(bit_array.begin(), bit_array.end()));
			int min_element = *(std::min_element(bit_array.begin(), bit_array.end()));
			if(min_element != bit_array[0] && max_element != bit_array[0]){
				std::cout<<std::endl;
				std::cerr<<"Error: Please enter the range starting from the target bit."<<std::endl;
				std::cerr<<"Please enter again: ";
				continue;
			}
      if(replace){
				std::vector<size_t> replace_gate;
				for(const auto v : bit_array){
					size_t position = toolbox::last_gate(components_vector[v]);
					replace_gate.push_back(position);
				}
				size_t largest_element = *(std::max_element(replace_gate.begin(), replace_gate.end()));
				for(const auto j: bit_array){
					j == bit_array.front() ? components_vector[j][largest_element] = pair(bit_array, gate_trgt) : components_vector[j][largest_element] = pair(bit_array, gate_ctrl);	
        }
				std::cout<<"Gate "<<symbol<<" added with target bit : q["<<bit_array[0]<<"]"<<std::endl;
        break;
      }
      else{
        for(const auto k: bit_array){
          k == bit_array.front() ? components_vector[k].push_back(pair(bit_array, gate_trgt)) : components_vector[k].push_back(pair(bit_array,gate_ctrl));
        }
        for (size_t i = 0; i < components_vector.size(); ++i) {
          auto it = std::find(bit_array.begin(), bit_array.end(), i);
          if (it == bit_array.end() && static_cast<int>(i) < num_qbits){
            components_vector[i].push_back(pair(std::make_shared<identity>()));
          }
        }
        std::cout<<"Gate "<<symbol<<" added with target bit : q["<<bit_array[0]<<"]"<<std::endl;
        break;
      }
    }
    else{
			std::cout<<std::endl;
      std::cout<<"Error: Invalid input. Please enter qubit numbers in the format 'q0,q1,...'." <<std::endl;
      std::cout<<"Please enter again: ";
      bit_array.clear();
    }
  }
}
void q_circuit::series_add(std::string gate_choice, std::shared_ptr<quantum_comp> gate)
{
  std::cout<<"Which q-bit would you like this gate to act on? (q0,q1,..)? "<<std::endl;
  std::cout<<"Selection: ";
  while(true){
    std::string bit_choice;
    std::getline(std::cin, bit_choice);
    std::cout<<std::endl;
    int chosen_no{toolbox::extract_number(bit_choice)};
    if(chosen_no > num_qbits-1){
      std::cout<<std::endl;
      std::cout<<"Error: There are only "<<num_qbits<<" qbits in the current circuit. You have entered q["<<chosen_no<<"]"<<std::endl;
      std::cout<<"Please enter again: ";
    }
    else if(chosen_no != -1){      
      int index = chosen_no;
      if(components_vector[index].back().second->get_symbol() != "[I]"){
        components_vector[index].push_back(pair(gate));
        for(int i{0}; i<static_cast<int>(components_vector.size()); i++){
          if(i == index || i > num_qbits-1){
            continue;
          }
          else{
            components_vector[i].push_back(pair(std::make_shared<identity>()));
          }
        }
      }
      else{
        size_t position = toolbox::last_gate(components_vector[index]);
        components_vector[index][position] = pair(gate);
      }
      std::cout<<"Gate ("<<toolbox::to_upper(gate_choice)<<") added to q["<<chosen_no<<"]"<<std::endl;
      std::cout<<std::endl;
      break;
    }
    else{
      std::cout<<std::endl;
      std::cout<<"Error: Cannot match to current qbit. (Enter q0/q1..etc): ";
    }
  }      
}
void q_circuit::parallel_add(std::shared_ptr<quantum_comp> gate)
{
  std::cout<<"Which q-bits would you like to apply this gate on?"<<std::endl;
  std::cout<<"Please enter as an array, with the target bit first e.g [q0,q1]: ";
	std::string symbol = gate->get_symbol();
  while(true){
    std::string input;
    std::getline(std::cin, input);
    std::vector<int> bit_array;
    bit_array = toolbox::extract_number(input, num_qbits);
    if(bit_array[0] == -2){
			std::cout<<std::endl;
      std::cout<<"Error: There are only "<<num_qbits<<" qbits in the current circuit."<<std::endl;
      std::cout<<"Please enter again: ";
    }
    else if(bit_array[0] != -1){
      bool replace{true};
      for(const auto& i: bit_array){
        if(components_vector[i].back().second->get_symbol() != "[I]"){
          replace = false;
        }
      }
      if(replace){
				std::vector<size_t> replace_gate;
				for(const auto v : bit_array){
					size_t position = toolbox::last_gate(components_vector[v]);
					replace_gate.push_back(position);
				}
				size_t largest_element = *(std::max_element(replace_gate.begin(), replace_gate.end()));
        std::cout<<"Gate "<<symbol<<" added on qbits :";
				for(const auto j: bit_array){
				  components_vector[j][largest_element] = pair(gate); 
				  std::cout<<"q["<<bit_array[j]<<"] ";
        }
        std::cout<<"."<<std::endl;
        break;
      }
      else{
        std::cout<<"Gate "<<symbol<<" added on qbits :";
        for(const auto k: bit_array){
          components_vector[k].push_back(pair(gate));
          std::cout<<"q["<<bit_array[k]<<"] ";
          std::cout<<"."<<std::endl;
        }
        for (size_t i = 0; i < components_vector.size(); ++i) {
          auto it = std::find(bit_array.begin(), bit_array.end(), i);
          if (it == bit_array.end() && static_cast<int>(i) < num_qbits){
            components_vector[i].push_back(pair(std::make_shared<identity>()));
          }
        }
        break;
      }
    }
    else{
			std::cout<<std::endl;
      std::cout<<"Error: Invalid input. Please enter qubit numbers in the format 'q0,q1,...'." <<std::endl;
      std::cout<<"Please enter again: ";
      bit_array.clear();
    }
  }
}
void q_circuit::add_gate()
{
  std::string gate_choice;
  std::string add_choice;
	std::cout<<"Possible gates: ";
	for(const auto& kv : Gate_a_base::gates){
    std::cout << kv.first<<", ";
  }
	std::cout<<std::endl;
	std::cout<<"What gate would you like to add? ";
  while(true){
		std::getline(std::cin, gate_choice);
    std::shared_ptr<quantum_comp> gate = Gate_a_base::search_library(0,gate_choice);
    if (gate != nullptr){
			int gate_range{gate->get_qbit_range()};
			if(gate_range > num_qbits){
				std::cout<<std::endl;
				std::cout<<"Error: Gate too big for circuit."<<std::endl;
				std::cout<<"Please enter again: ";
				continue;
			}
      else if(gate_range > 1){
        multi_qbit_gate(gate, gate_range, num_qbits);
        break;
      }
      std::cout<<"Would you like to add your gate in: "<<std::endl;
      std::cout<<"1) Series."<<std::endl<<"2) Parallel.";
      while(true){
		    std::getline(std::cin, add_choice);
        if(add_choice.empty()){
          std::cout<<"Error: Empty entry."<<std::endl;
          std::cout<<"Please enter again."<<std::endl;
          continue;
        }
        int add_choice_int = toolbox::int_verifier(add_choice);
        if(add_choice_int == 1){
          series_add(gate_choice, gate);
          break;
        }
        else if(add_choice_int == 2){
          parallel_add( gate);
          break;
        }
        else{
          std::cout<<"Error: Invalid entry. "<<std::endl;
          std::cout<<"Please enter again: ";
        }   
      }
      break;
    }
  }
  std::cout<<"Updated Circuit:"<<std::endl;
  this->draw_circuit();
	//std::this_thread::sleep_for(std::chrono::milliseconds(2500));
  std::cout<<std::endl;
}
void q_circuit::gate_info()
{
	std::cout<<"Which gate would you like to see the information for? "<<std::endl;
	std::cout<<"Possible gates: ";
	for(const auto& kv : Gate_a_base::gates){
    std::cout << kv.first<<", ";
	}
	std::cout<<std::endl;
	std::string gate_choice;
	while(true){
    std::getline(std::cin, gate_choice);
		std::shared_ptr<quantum_comp> gate = Gate_a_base::search_library(0,gate_choice);
		if(gate != nullptr){
			std::cout<<std::endl;
			gate->get_info();
			//std::this_thread::sleep_for(std::chrono::seconds(4));
      std::cout<<"* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * "<<std::endl;
			std::cout<<std::endl;
			break;
		}
	}
}
void q_circuit::create_circuit()
{	
  std::string qbit_choice;
  std::cout<<"How many q-bits would you like in your circuit? (maximum of 5) ";
  while(true){
    std::getline(std::cin, qbit_choice);
    int qbits{toolbox::int_verifier(qbit_choice)};
		if(qbits == -1){
			std::cout<<std::endl;
			std::cerr<<"Error: Invalid Entry"<<std::endl;
			std::cout<<"Please enter again: ";
		}
    else if(qbits > 5 || qbits < 1){
			std::cout<<std::endl;
      std::cout<<"Error: The number of qbits should be beteen 1 and 5."<<std::endl;
      std::cout<<"Please enter again: ";
    }
    else if(qbits != -1){
			*this = q_circuit(qbits);
      std::cout<<"Circuit with "<<qbit_choice<<" qbit(s) and 1 classical bit created."<<std::endl;
      std::cout<<std::endl;
      break;
    }
  }
}
void q_circuit::draw_circuit() 
{
  std::cout<<std::endl;
  for (int i{0}; i < (total_bits); i++){
		std::stringstream ss;
		int counter{0};
		int total_ss_length{0};
    for (size_t k{0}; k < components_vector[i].size(); k++){
			circ_element gate = components_vector[i][k];
      std::string symbol = gate.second->get_symbol();
      if(symbol == "[I]"){
        std::cout << "-----";
      } 
      else if(symbol == "q"){
        std::cout<<"q["<<i<<"]--";
        if (components_vector[i].size() == 1){
          std::cout<<"------------------------------";
        }
				ss<<std::string(6, ' ');
      } 
      else if(symbol == "c"){
        std::cout<<"c["<<i-num_qbits<<"]==";
        if (toolbox::longest_element(components_vector) == 1){
          std::cout<<"===============================";
        }
        else{
				int longest_bit{static_cast<int>(toolbox::longest_element(components_vector))};
				std::string creg = std::string(5*(longest_bit-1), '=');
        std::cout<<creg;
        }
      } 
      else {
				int symbol_length = symbol.length();
				if (symbol == "⊕" || symbol == "•" || symbol == "■" ){
        	symbol_length -= 2;
      	} 
        int alignment_length{(3-symbol_length+2)/2};
        std::string padding(alignment_length, '-');
        std::cout<<padding<<symbol<<padding;

				//To connect the bits in controlled, multi-qbit gates
				if (symbol == "⊕" || symbol == "•" || symbol == "■" || symbol == "x"){
					
          std::vector<int> gates_copy = (gate.first);
          std::sort(gates_copy.begin(), gates_copy.end()); 
          gates_copy.pop_back();
          auto i_is_bit = std::find(gates_copy.begin(), gates_copy.end(), i);
          if(i_is_bit != gates_copy.end()){
            int filler_length = 5*(k) - 3 - total_ss_length;
            if (filler_length > 0){ 
              std::string filler(filler_length, ' ');
              ss << filler << "|";
              total_ss_length += filler.length() + 1;  
            }
				  }
					counter+=k;
    		} 
    	}
  	}
		std::cout<<std::endl;
		std::cout<<ss.str();
    std::cout<<std::endl;
  }
	std::cout<<" * * * * * * * * * * * * * * * * * * * *";
  std::cout << std::endl;
}
void q_circuit::remove_gate()
{ 
  size_t longest_row{toolbox::longest_element(components_vector)};
  if(longest_row == 1){
    std::cout<<"No gates in circuit yet!"<<std::endl;
    std::cout<<std::endl;
  }
  else{
    std::cout<<"Current Circuit: "<<std::endl;
    this->draw_circuit();
    std::string removal_choice;
    int counter{1};
    std::map<int, std::pair<int, int>> counter_to_gate_map;
    std::cout<<"What gate would you like to remove?"<<std::endl;
    std::cout<<"Options:"<<std::endl;
    for(size_t k{1}; k < longest_row; k++){
      for(size_t i{0}; i < components_vector.size()-1; i++){
        circ_element gate = components_vector[i][k];
        std::string symbol = gate.second->get_symbol();
        if(symbol != "[I]" && symbol != "•"){
          symbol = gate.second->get_name();
          if(gate.second->get_qbit_range() > 1){
            auto it = std::find(gate.first.begin(), gate.first.end(), i);
            if(it != gate.first.end()){
              continue;
            }
          }
          std::cout<<counter<<") Gate: "<<symbol<<" on "<<"q["<<i<<"]"<<std::endl;
          counter_to_gate_map[counter] = std::make_pair(i,k);
          counter ++;
        }
      }
    }  
    while(true){
      std::cout<<"Selection: ";
      std::getline(std::cin,removal_choice);
      if(!removal_choice.empty()){
        //Selected option 'option'
        int option{toolbox::int_verifier(removal_choice)};
        if (counter_to_gate_map.find(option) != counter_to_gate_map.end()){
          //Chosen gate with circuit 'coordinates' (bit_choice,gate_choice)
          int bit_choice{counter_to_gate_map[option].first};
          int gate_choice{counter_to_gate_map[option].second};
          circ_element gate = components_vector[bit_choice][gate_choice];
          std::string symbol = gate.second->get_name();
          for(auto v : gate.first){
            components_vector[v][gate_choice] = pair(std::make_shared<identity>()); 
          }
          components_vector[bit_choice][gate_choice] = pair(std::make_shared<identity>()); 
          bool identity_column{true};
          for(int i{0}; i<num_qbits; i++){
            if(components_vector[i][gate_choice].second->get_symbol() != "[I]"){
              identity_column = false;
            }
          }
          if(identity_column){
            for(int i{0}; i<num_qbits; i++){
              components_vector[i].erase(components_vector[i].begin() + gate_choice);
            }
          }
          std::cout<<"Gate: "<<symbol<<" on q["<<bit_choice<<"] removed successfully."<<std::endl;
          std::cout<<"Updated Circuit:"<<std::endl;
          this->draw_circuit();
          break;
        }
        else{
          std::cout<<std::endl;
          std::cout<<"Error: Invalid Entry."<<std::endl;
          std::cout<<"Please enter again: "<<std::endl; 
        }
      }
      else{
        std::cout<<std::endl;
        std::cout<<"Error: Empty entry."<<std::endl;
        std::cout<<"Please enter again: ";
      }
    }
  }
}
void q_circuit::calculate_circuit_matrix(int gate_pos)
{ 
  int longest_row{static_cast<int>(toolbox::longest_element(components_vector)-1)};
  if(longest_row == 0){
		std::cout<<std::endl;
    std::cout<<"Error: No gates in circuit yet!"<<std::endl;
    return;
  }
  if(gate_pos <= longest_row){
    matrix gate_tensor = components_vector[0][gate_pos].second->get_matrix(); 
    toolbox::recursive_tensor_product(components_vector, num_qbits , 1, gate_pos, gate_tensor);
    tensor_vector.push_back(gate_tensor);
    gate_pos++;
    calculate_circuit_matrix(gate_pos);
  }
  else if(gate_pos > longest_row){
    circuit_matrix = tensor_vector[0];
		//Mutliplies the tensor matrices of every gate produce together
    toolbox::recursive_matrix_multiplication(tensor_vector, 1, circuit_matrix);
		//Tensor product of qbit states
		matrix qbit_tensor = components_vector[0][0].second->get_matrix(); 
		toolbox::recursive_tensor_product(components_vector, num_qbits, 1, 0, qbit_tensor);
		//qbit tensor matrix mutiplied by circuit matrix
		matrix applied_matrix = circuit_matrix * qbit_tensor;
    std::cout<<"Circuit Matrix representation:"<<std::endl;
    std::cout<<circuit_matrix<<std::endl;
		std::cout<<std::endl;
		std::cout<<"Applied to q-bit register: "<<std::endl;
		std::cout<<applied_matrix<<std::endl;
		std::cout<<"(qbits initalized in the ket 0 basis state)"<<std::endl;
		std::cout<<std::endl;
  }
}
void q_circuit::get_circuit_matrix()
{ 
  tensor_vector.clear();
  int gate_pos{1};
  calculate_circuit_matrix(gate_pos);
}
void q_circuit::save()
{	  
  size_t longest_row{toolbox::longest_element(components_vector)};
  if(longest_row == 1){
    std::cout<<"No gates in circuit yet!"<<std::endl;
    std::cout<<std::endl;
  }
  else{
    saved_circuits.push_back(std::make_shared<q_circuit>(*this));
    size_t size{saved_circuits.size()};
    std::cout<<std::endl;
    std::cout<<"SAVING";
    for(int i{0}; i < 40; i++){
      std::cout<<".";
      std::cout.flush();
     //std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    for (int i = 0; i < 47; i++) {
        std::cout << '\b' << ' ' << '\b';
    }
    std::cout<<std::endl;
    std::cout<<" * * * * * * * * * * * * * * * * * * * *"<<std::endl;
    std::cout<<"       Circuit saved as: Circuit "<<size<<"."<<std::endl;
    std::cout<<" * * * * * * * * * * * * * * * * * * * *"<<std::endl;
    std::cout<<std::endl;
   //std::this_thread::sleep_for(std::chrono::seconds(3));
  }
}
void q_circuit::add_to_circuit(std::shared_ptr<q_circuit> circuit, int circ_no)
{
  size_t longest_added_bit = toolbox::longest_element(circuit->components_vector);
  std::cout<<std::endl;
  std::cout<<"Which bit would you like to add the circuit to? [q0,q1...]"<<std::endl;
  std::cout<<"Selection: ";
  while(true){
    std::string bit_choice;
    std::getline(std::cin, bit_choice);
    if(!bit_choice.empty()){
      int bit_choice_numb{toolbox::extract_number(bit_choice)};
      if(bit_choice_numb != -1 && (bit_choice_numb >= 0 && bit_choice_numb < this->num_qbits)){
        if((this->num_qbits-bit_choice_numb) >= circuit->num_qbits){
          std::vector<int> changed_bits;
          for(int l{bit_choice_numb}; l < (bit_choice_numb+circuit->num_qbits); l++){
            changed_bits.push_back(l);
          }
          for(size_t k{1}; k < longest_added_bit; k++){
            for(int j{0}; j < this->num_qbits; j++){
              auto it = std::find(changed_bits.begin(), changed_bits.end(), j);
              if (it == changed_bits.end()){
                this->components_vector[j].push_back(pair(std::make_shared<identity>()));
              }
              else{
                this->components_vector[j].push_back(circuit->components_vector[j-bit_choice_numb][k]);
              }
            }
          }
          std::cout<<"Circuit "<<circ_no<<" added to current circuit."<<std::endl;
          std::cout<<"Updated Circuit:"<<std::endl;
          this->draw_circuit();
          break;
        }
        else{
          std::cout<<std::endl;
          std::cout<<"Error: Not enough space in current circuit to add on that bit."<<std::endl;
          std::cout<<"#qbits in current circuit: "<<this->num_qbits<<std::endl;
          std::cout<<"#qbits in added circuit: "<<circuit->num_qbits<<std::endl;
          std::cout<<"Please enter again: ";
          continue;
        }
      }
      else{
        std::cout<<"Error: Invalid entry."<<std::endl;
        std::cout<<"Please enter again: ";
        continue;
      }
    }
    else{
      std::cout<<"Error: Empty entry"<<std::endl;
      std::cout<<"Please enter again: ";
      continue;
    }  
  }
}
void q_circuit::load()
{
  if(saved_circuits.size() == 0){
    std::cout<<"Error: No circuits have been saved yet."<<std::endl;
  }
  else{
    std::cout<<std::endl;
    std::cout<<"Options: "<<std::endl;
    std::cout<<std::endl;
    for(size_t i{0};i < saved_circuits.size(); i++){
      std::cout<<i+1<<") Circuit "<<i+1<<std::endl;
      saved_circuits[i]->draw_circuit();
      std::cout<<std::endl;
    }
    std::cout<<"Which circuit would you like to load?"<<std::endl;
    std::cout<<"Selection: ";
    while(true){
      std::string circuit_choice;
      std::getline(std::cin, circuit_choice);
      if(!circuit_choice.empty()){
        int circuit_number{toolbox::int_verifier(circuit_choice)};
        if(circuit_number > 0 && circuit_number <= static_cast<int>(saved_circuits.size())){
          std::cout<<"You have selected Circuit "<<circuit_number<<std::endl;
          std::cout<<std::endl;
          std::cout<<"Would you like to:"<<std::endl;
          std::cout<<"1) Overwrite current circuit? "<<std::endl;
          std::cout<<"2) Add this to your current circuit? "<<std::endl;
          std::cout<<std::endl;
          std::cout<<"Selection: ";
          std::string load_choice;
          std::getline(std::cin, load_choice);
          if(!load_choice.empty()){
            int load_choice_numb{toolbox::int_verifier(load_choice)};
            if(load_choice_numb == 1){
              std::cout<<"Circuit Overwritten."<<std::endl;
              std::cout<<"Updated Circuit: "<<std::endl;
              *this = *saved_circuits[circuit_number-1]; 
              this->draw_circuit();
              break;
            }
            //Add to circuit  
            else if(load_choice_numb == 2){
              if(this->num_qbits >= saved_circuits[circuit_number-1]->num_qbits){
              this->add_to_circuit(saved_circuits[circuit_number-1], circuit_number);
              break;
              }
              else{
                std::cout<<"Error: Saved circuit too large to be added to current circuit"<<std::endl;
                std::cout<<"Try option 1 (Overwrite current circuit.)"<<std::endl;
                break;
              }
            }
            else{
              std::cout<<"Error: Option not in range."<<std::endl;
              std::cout<<"Please enter again: ";
            }    
          }
          else{
              std::cout<<"Error: Empty entry"<<std::endl;
              std::cout<<"Please enter again: ";
          }
        }
        else{
          std::cout<<"Error: Option not in range."<<std::endl;
          std::cout<<"Please enter again: ";
        }
      }
      else {
        std::cout<<"Error: Empty entry"<<std::endl;
        std::cout<<"Please enter again: ";
      }
    }
  } 
}

circ_element q_circuit::pair(std::vector<int> qbit_choice, std::shared_ptr<quantum_comp> gate)
{
	circ_element component_selection;
	component_selection.first = qbit_choice;
	component_selection.second = gate;
	return component_selection;
}
circ_element q_circuit::pair(std::shared_ptr<quantum_comp> gate) 
{
	std::vector<int> qbit_choice;
  return pair(qbit_choice, gate);
}


// in cpp file:
// std::vector<std::shared_ptr<q_circuit>> q_circuit::saved_circuits;

//main.cpp
void submenu(std::shared_ptr<q_circuit> circuit)
{
	while(true){
   //std::this_thread::sleep_for(std::chrono::milliseconds(750));
		std::cout<<"Options:"<<std::endl;
		std::cout<<"1) Add gate."<<std::endl;
		std::cout<<"2) Remove Gate."<<std::endl;
		std::cout<<"3) See circuit."<<std::endl;
		std::cout<<"4) See circuit matrix."<<std::endl;
    std::cout<<std::endl;
    std::cout<<"Or:"<<std::endl;
		std::cout<<"5) Save Circuit."<<std::endl;
		std::cout<<"6) Load Circuit."<<std::endl;
    std::cout<<"7) New circuit."<<std::endl;
		std::cout<<"8) See gate information."<<std::endl;
    std::cout<<"9) Exit program."<<std::endl;
		std::cout<<std::endl;
		std::cout<<"Please pick an option: ";

		std::string choice_2;
		std::getline(std::cin, choice_2);
		if(!choice_2.empty()){
      int option2{toolbox::int_verifier(choice_2)};
			if(option2 < 1 || option2 > 9){
				std::cout<<std::endl;
				std::cerr<<"Error: Please select one of the options:"<<std::endl;
				std::cout<<std::endl;
			}
      if(option2 == 1){circuit->add_gate();}
      if(option2 == 2){circuit->remove_gate();}
      if(option2 == 3){circuit->draw_circuit();}
      if(option2 == 4){circuit->get_circuit_matrix();}
      if(option2 == 5){circuit->save();}
      if(option2 == 6){circuit->load();}
      if(option2 == 7){
        circuit->create_circuit();
      	submenu(circuit);
      }
      if(option2 == 8){circuit->gate_info();}
      if(option2 == 9){
        std::cout<<"Thank you for using this program!"<<std::endl;
        std::cout<<"************************************************"<<std::endl;
        exit(1);
      }
    }
    else {
      std::cout<<"Empty entry!"<<std::endl;
      std::cout<<"Please enter again: "<<std::endl;
    }
	}
}
void menu()
{
 std::cout<<"************************************************"<<std::endl;
 std::cout<<"    Welcome to the Quantum Circuits Program!"<<std::endl;
 std::cout<<"************************************************"<<std::endl;
 std::cout<<std::endl;
 std::shared_ptr<q_circuit> default_circuit = std::make_shared<q_circuit>();
 while(true){
 //std::this_thread::sleep_for(std::chrono::milliseconds(750));
	std::cout<<"Options:"<<std::endl;
	std::cout<<"1) Create quantum circuit."<<std::endl;
	std::cout<<"2) See gate information."<<std::endl;
	std::cout<<"3) Exit program."<<std::endl;
	std::cout<<std::endl;
	std::cout<<"Please pick an option: ";

	std::string choice_1;
	std::getline(std::cin, choice_1);
  if(!choice_1.empty()){
    int option1{toolbox::int_verifier(choice_1)};
		if(option1 < 1 || option1 > 3){
			std::cout<<std::endl;
			std::cerr<<"Error: Please select one of the options:"<<std::endl;
			std::cout<<std::endl;
		}
    if(option1 == 1){
      default_circuit->create_circuit();
      submenu(default_circuit);
    }
		if(option1 == 2){default_circuit->gate_info();}
    if(option1 == 3){
      std::cout<<"Thank you for using this program!"<<std::endl;
      std::cout<<"************************************************"<<std::endl;
      exit(1);
    }
  }
  else {
    std::cout<<"Empty entry!"<<std::endl;
  }
 }
}

int main()
{
	menu();
  return 0;
}


/*
TO DO:
 move semantics
   
 FINAL TOUCHES:
  REVIEW ADVANCED FEATURES/
  HOUSE STYLE.

*/

